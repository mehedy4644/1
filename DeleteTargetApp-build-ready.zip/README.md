# Delete guest100067.dat (Android source project)

This Android Studio project targets only the file:
`/storage/67DE-F402/FF/Guest/guest100067.dat`

## How it works
- On first launch, tap **SELECT FF FOLDER**.
- In Android's system folder picker, open the removable SD card `67DE-F402`, select the **FF** folder itself, and grant access using **Use this folder**.
- Tap **DELETE FILE**. The app looks only for `Guest/guest100067.dat` beneath the selected FF folder. It does not delete the directory or other files.

The storage volume ID (`67DE-F402`) can vary between devices/cards. Android's Storage Access Framework grants access to the folder selected by the user, rather than relying on a hard-coded raw filesystem permission. The project source is provided; an APK has not been built or tested on a device.

## Build
Open `DeleteTargetApp` in Android Studio, allow Gradle sync, then use **Build > Build APK(s)**. Compile SDK 35 and AndroidX DocumentFile 1.0.1 are used.
