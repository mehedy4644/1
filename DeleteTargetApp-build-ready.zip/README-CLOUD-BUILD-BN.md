# ফোন দিয়েই APK তৈরি করার নির্দেশনা

এই ZIP-এ Android source project এবং GitHub Actions cloud build workflow আছে। এই চ্যাটে APK সরাসরি compile করা হয়নি।

1. ZIP extract না করেও GitHub ওয়েবসাইটে নতুন repository তৈরি করুন।
2. ZIP-এর ভেতরের সব ফাইল repository-তে upload করুন—বিশেষ করে `.github/workflows/build-apk.yml` যেন upload হয়। GitHub মোবাইল ওয়েব UI-তে একসঙ্গে folder upload সমর্থিত না হলে ফোনের browser-এ Desktop site ব্যবহার করতে হতে পারে।
3. Repository-র **Actions** tab খুলুন। প্রথমবার workflow enable করতে বললে enable করুন।
4. **Build Android APK** workflow → **Run workflow** চাপুন (বা main branch-এ ফাইল upload করার পর স্বয়ংক্রিয় run শেষ হওয়া পর্যন্ত অপেক্ষা করুন)।
5. সফল run খুলে নিচের **Artifacts** অংশ থেকে `DeleteTargetApp-debug-apk` ডাউনলোড করুন। ZIP extract করে `app-debug.apk` ইনস্টল করুন।

প্রথমবার চালু করে SD card-এর `FF` ফোল্ডারটি নির্বাচন করে অনুমতি দিন। অ্যাপটি এরপর `FF/Guest/guest100067.dat`-কেই লক্ষ্য করবে। APK-টি বাস্তব ডিভাইসে পরীক্ষা করা হয়নি; SD-card provider অনুযায়ী folder picker/permission আচরণ ভিন্ন হতে পারে।
