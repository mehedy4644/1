package com.example.deletetarget;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.content.SharedPreferences;
import androidx.documentfile.provider.DocumentFile;

public class MainActivity extends Activity {
    private static final int REQUEST_TREE = 100;
    private static final String PREFS = "target_access";
    private static final String TREE_URI = "ff_tree_uri";
    private TextView status;
    private Button actionButton;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        buildUi();
        updateUi();
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(36), dp(24), dp(24));
        root.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("Delete guest100067.dat"); title.setTextSize(23); title.setTextColor(Color.BLACK);
        title.setGravity(Gravity.CENTER); title.setTypeface(null, 1);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView path = new TextView(this);
        path.setText("Target file:\n/storage/67DE-F402/FF/Guest/guest100067.dat");
        path.setTextSize(14); path.setTextColor(Color.DKGRAY); path.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, -2); pp.topMargin = dp(24);
        root.addView(path, pp);

        TextView instructions = new TextView(this);
        instructions.setText("প্রথমবার ‘SELECT FF FOLDER’ চাপুন এবং SD card-এর FF ফোল্ডারটি নির্বাচন করে ‘Use this folder’ অনুমতি দিন। এরপর DELETE FILE চাপুন।");
        instructions.setTextSize(14); instructions.setTextColor(Color.DKGRAY); instructions.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2); ip.topMargin = dp(20);
        root.addView(instructions, ip);

        actionButton = new Button(this);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2); bp.topMargin = dp(24);
        root.addView(actionButton, bp);
        actionButton.setOnClickListener(v -> {
            Uri saved = getSavedTreeUri();
            if (saved == null) selectFolder(); else deleteTarget(saved);
        });

        Button change = new Button(this);
        change.setText("SELECT / CHANGE FF FOLDER");
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.topMargin = dp(8);
        root.addView(change, cp);
        change.setOnClickListener(v -> selectFolder());

        status = new TextView(this); status.setTextSize(14); status.setTextColor(Color.DKGRAY); status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2); sp.topMargin = dp(20);
        root.addView(status, sp);

        TextView note = new TextView(this);
        note.setText("অ্যাপটি শুধু FF/Guest/guest100067.dat ফাইলটিই খুঁজে ডিলিট করবে। ফোল্ডার বা অন্য ফাইল ডিলিট করবে না।");
        note.setTextSize(12); note.setTextColor(Color.GRAY); note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2); np.topMargin = dp(28);
        root.addView(note, np);
        setContentView(root);
    }

    private Uri getSavedTreeUri() {
        String s = prefs.getString(TREE_URI, null);
        if (s == null) return null;
        try { return Uri.parse(s); } catch (Exception e) { return null; }
    }

    private void updateUi() {
        boolean selected = getSavedTreeUri() != null;
        actionButton.setText(selected ? "DELETE FILE" : "SELECT FF FOLDER");
        status.setText(selected ? "FF folder access saved. Ready to delete the exact target file." : "প্রথমে SD card-এর FF ফোল্ডার নির্বাচন করুন।");
    }

    private void selectFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        // Android restricts selecting some storage roots on newer versions; user should select the FF folder itself.
        startActivityForResult(intent, REQUEST_TREE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_TREE || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri tree = data.getData();
        try {
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(tree, flags);
            DocumentFile picked = DocumentFile.fromTreeUri(this, tree);
            if (picked == null || !picked.isDirectory() || !"FF".equalsIgnoreCase(picked.getName())) {
                status.setText("অনুগ্রহ করে SD card-এর FF নামের ফোল্ডারটি নির্বাচন করুন।");
                return;
            }
            prefs.edit().putString(TREE_URI, tree.toString()).apply();
            status.setText("FF folder access saved.");
            updateUi();
        } catch (Exception e) {
            status.setText("Folder permission failed: " + e.getMessage());
        }
    }

    private void deleteTarget(Uri treeUri) {
        try {
            DocumentFile ff = DocumentFile.fromTreeUri(this, treeUri);
            if (ff == null || !ff.isDirectory() || !"FF".equalsIgnoreCase(ff.getName())) {
                prefs.edit().remove(TREE_URI).apply();
                status.setText("FF folder access is invalid. Please select the FF folder again.");
                updateUi();
                return;
            }
            DocumentFile guest = ff.findFile("Guest");
            if (guest == null || !guest.isDirectory()) {
                status.setText("Guest folder not found inside FF.");
                return;
            }
            DocumentFile target = guest.findFile("guest100067.dat");
            if (target == null || !target.isFile()) {
                status.setText("guest100067.dat was not found. No other file was changed.");
                return;
            }
            boolean deleted = target.delete();
            status.setText(deleted ? "SUCCESS: guest100067.dat deleted." : "Delete failed. Check folder permission and try again.");
        } catch (SecurityException e) {
            status.setText("Access denied. Select the FF folder again and grant permission.");
        } catch (Exception e) {
            status.setText("Error: " + e.getMessage());
        }
    }
}
